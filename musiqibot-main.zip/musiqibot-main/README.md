# SongPlayRoBot
3X Fast Telethon Based Bot ⚜

Open Source Bot 👨🏻‍💻

Demo : [SongPlayRoBot](https://t.me/SongPlayRoBot) 💃🏻

Easy To Deploy 🤗

# Click Below Image to Deploy
[![Deploy](https://telegra.ph/file/cb7b0aead06c96955323e.jpg)](https://heroku.com/deploy?template=https://github.com/IVETRI/SongPlayRoBot.git)
# DEPLOY
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/IVETRI/SongPlayRoBot.git)

# Group
You can also join our support group [HERE!](https://t.me/TamilSupport) 👨🏻‍💻

# Report error
Report your problem along with your name to This [PERSON](https://t.me/IMVETRI) 😪
## credits
This Repo Is Just A Custom Fork Of [Alexa](https://github.com/Mr-SHRLCK/Alexa)
Thanks to [「𝙨𝙝є𝙧𝙡σ𝙘𝙠」](https:t.me/Mr_SRLOCK)
